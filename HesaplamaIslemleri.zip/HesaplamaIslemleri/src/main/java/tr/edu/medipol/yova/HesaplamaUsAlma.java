package tr.edu.medipol.yova;



public class HesaplamaUsAlma {
	  
    public static void main(String[] args) {
        int taban = 4, kuvvet = 5;
 
        double sonuc = Math.pow(taban, kuvvet);
 
        System.out.println("CEVAP = " + sonuc);
    }
}